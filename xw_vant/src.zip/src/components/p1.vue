<template>
  <div>
     
           <span>孙春兰：加强高校创新能力开放合作，更好地服务党和国家工作大局</span>
  
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
span{
    display: block;
    height:1.2rem;
    width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space:nowrap;
    font-size: .3rem;
    line-height: 1.2rem;
  }
 
</style>
